#### WhatsApp Bot
This is done using python selenium.

You Need the following things to be downloaded:
1)Selenium
2)Chrome webdriver
3)whatsapp account(web.whattsapp.com)

Step1: Install Selenium
($pip install selenium)

Step 2: Download Chrome Webdrive
($pip install chromium-browser)

Step 3: Create Project Folder and put this python file and unzip chrome webdriver

Step 4:Clone the respository.($ git clone "url")

IMP:(Open whatsapp_sendmessage.py and change the target name and frequency to the name of your contact)after that,
RUN:($python whatsapp_sendmessage.py)

Step 6: It ask QR code scanner. Please link your whatsapp account.

DONE.



#### Run the command to Send Message

``` python whatsapp_sendmessage.py ```


#### Run the command to get Recent Chat Contacts

``` python whatsapp_contacts.py ```
